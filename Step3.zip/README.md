---
contributors:
  - Lars Vilhuber
---

# README for simple example


## Overview

This is the package that will generate the table in the paper "Simple stuff in Alaska". It contains only public-use data (provided), runs on Stata, and is very quick to run.

## Data Availability and Provenance Statements


### Statement about Rights

- [x] I certify that the author(s) of the manuscript have legitimate access to and permission to use the data used in this manuscript. 
- [x] I certify that the author(s) of the manuscript have documented permission to redistribute/publish the data contained within this replication package. Appropriate permission are documented in the [LICENSE.txt](LICENSE.txt) file.


### Summary of Availability

- [x] All data **are** publicly available.
- [ ] Some data **cannot be made** publicly available.
- [ ] **No data can be made** publicly available.

### Details on each Data Source


### Census of Population and Housing, 2000

We use the Census 2000 from ICPSR.

> United States. Bureau of the Census. Census of Population and Housing, 2000 [United States]:  Public Use Microdata Sample:  5-Percent Sample    . [distributor], 2006-01-12. https://doi.org/10.3886/ICPSR13568.v1

Datafile:  `13568-0002-Data.txt`

The data are in the public domain (produced by the US Gov't), and were obtained from ICPSR without a login or any other further restrictions. By downloading, we agreed to ICPSR's standard terms of use.

## Computational requirements


### Software Requirements


- Stata (code was last run with version 16)
  - `latab` (as of 2023-09-19)
  All packages are installed by the code itself.


### Controlled Randomness

No randomness.

### Memory and Runtime Requirements


#### Summary

Approximate time needed to reproduce the analyses on a standard (CURRENT YEAR) desktop machine:

- [x] <10 minutes
- [ ] 10-60 minutes
- [ ] 1-2 hours
- [ ] 2-8 hours
- [ ] 8-24 hours
- [ ] 1-3 days
- [ ] 3-14 days
- [ ] > 14 days
- [ ] Not feasible to run on a desktop machine, as described below.

#### Details

2018 laptop: 

Processor	Intel(R) Core(TM) i7-8550U CPU @ 1.80GHz   1.99 GHz
Installed RAM	8.00 GB (7.85 GB usable)


## Description of programs/code

- 01_prep.do prepares the data
- 02_table.do creates the table

## Instructions to Replicators

- Run `programs/master.do`

### Details


## List of tables and programs

The provided code reproduces:

- [ ] All numbers provided in text in the paper
- [x] All tables and figures in the paper
- [ ] Selected tables and figures in the paper, as explained and justified below.


| Figure/Table #    | Program                  | Line Number | Output file                      | Note                            |
|-------------------|--------------------------|-------------|----------------------------------|---------------------------------|
| Table 1           | 02_table.do    |             | freq_specific_ak.tex                 ||


## References

- United States. Bureau of the Census. Census of Population and Housing, 2000 [United States]:  Public Use Microdata Sample:  5-Percent Sample    . [distributor], 2006-01-12. https://doi.org/10.3886/ICPSR13568.v1


---

## Acknowledgements

Some content on this page was copied from [Hindawi](https://www.hindawi.com/research.data/#statement.templates). Other content was adapted  from [Fort (2016)](https://doi.org/10.1093/restud/rdw057), Supplementary data, with the author's permission.
